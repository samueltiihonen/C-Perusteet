﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valinta_luvun_vertailu
{
    class Program
    {
        static void Main(string[] args)
        {11 C# Valinta: Luvun vertailutehtävä

        //Console.Write("anna luku: ");
        int value = int.Parse(Console.readline());

         if (value == 0)
            {
                Console.writeline("arvo on 0");

            }
         else if (value > 0)

                Console.writeline("arvo on suurempi kuin 0);"
           { }
           else


                Consolewriteline(Arvo on suurempi kuin =); 
        






         Console.ReadKey();
        }
    }
}
