﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luvun_arvaus
{
    class Program
    {
        static void Main(string[] args)
        {
            int target = 11;
               
            
            Console.WriteLine(Arvaa luku(0 - 20); =);
            int guess = int.Parse(Console.ReadLine());
            
            
            if (guess == target) // oikea arvaus

            {
                Console.Writeline("oikea arvaus");

                else if (guess < taget) // liian pieni

                    Console.writeline(liian pieni");" +


                else // liian suuri


                    Console.WriteLine("liian suuri");
                    

            


















            Console.ReadKey();
        }
    }
}
